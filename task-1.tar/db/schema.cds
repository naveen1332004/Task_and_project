namespace my.vehicle;

entity Vehicles {
  key ID : UUID;
  status : String;
  dealerEmail : String;
}