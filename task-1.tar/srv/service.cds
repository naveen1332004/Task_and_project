using my.vehicle as db;

service VehicleService {

  entity Vehicles as projection on db.Vehicles actions {
    action approveVehicle() returns String;
    action notifyDealer() returns String;
  }

}