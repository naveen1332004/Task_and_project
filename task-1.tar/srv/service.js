const cds = require('@sap/cds');

module.exports = cds.service.impl(function () {

  const { Vehicles } = this.entities;


  this.on('approveVehicle', async (req) => {
    const ID = req.params[0].ID;

    await UPDATE(Vehicles)
      .set({ status: 'Approved' })
      .where({ ID });

    // Trigger second action internally
    await this.emit('notifyDealer', { ID });

    return `Vehicle ${ID} approved and dealer notified`;
  });


  this.on('notifyDealer', async (req) => {
    const ID = req.params?.[0]?.ID || req.data.ID;

    const vehicle = await SELECT.one.from(Vehicles).where({ ID });

    if (!vehicle) {
      return req.error(404, 'Vehicle not found');
    }

    // Simulate notification
    console.log(`Email sent to dealer: ${vehicle.dealerEmail}`);

    return `Dealer notified for vehicle ${ID}`;
  });

});
